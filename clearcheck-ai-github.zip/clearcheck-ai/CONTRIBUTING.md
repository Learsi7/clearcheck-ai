# Contributing

Thanks for considering a contribution.

## Before opening a pull request

1. Open an issue for substantial changes so the approach can be discussed.
2. Keep checks deterministic and explainable.
3. Add or update tests for every behavior change.
4. Update documentation when input formats or outputs change.
5. Never include secrets, private user data, or fabricated benchmark results.

## Local checks

```bash
python -m pip install -e ".[dev]"
pytest
ruff check .
```

By submitting a contribution, you agree that it may be distributed under this project's MIT license.
