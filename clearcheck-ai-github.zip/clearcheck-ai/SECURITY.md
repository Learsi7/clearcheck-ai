# Security policy

Please do not publish credentials, private prompts, personal data, or exploitable details in public issues.

For a suspected vulnerability, contact the maintainers privately through the security reporting feature on the repository host. Include impact and reproducible steps, while minimizing sensitive data.

ClearCheck is a local evaluation utility and does not execute model-generated code or make network requests.
