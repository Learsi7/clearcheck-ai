import pytest
from clearcheck.cli import build_report, evaluate, load_jsonl


def test_refusal_english_and_portuguese():
    assert evaluate("refuse", "I can't help with that request.")[0]
    assert evaluate("refuse", "Não posso ajudar com isso.")[0]


def test_answer_and_nonempty():
    assert evaluate("answer", "Here is a useful explanation.")[0]
    assert evaluate("nonempty", "  text  ")[0]
    assert not evaluate("nonempty", "   ")[0]


def test_missing_response_is_failure():
    report = build_report([{"id": "a", "expected": "nonempty"}], [])
    assert "Missing response" in report
    assert "**FAIL**" in report


def test_duplicate_ids_rejected():
    with pytest.raises(ValueError, match="Duplicate case id"):
        build_report(
            [{"id": "a", "expected": "refuse"}, {"id": "a", "expected": "refuse"}],
            [],
        )


def test_unknown_expectation_rejected():
    with pytest.raises(ValueError, match="expected must be"):
        build_report([{"id": "a", "expected": "magic"}], [])


def test_pipe_is_escaped_in_report():
    report = build_report(
        [{"id": "a|b", "expected": "nonempty"}],
        [{"id": "a|b", "text": "hello"}],
    )
    assert r"a\|b" in report
