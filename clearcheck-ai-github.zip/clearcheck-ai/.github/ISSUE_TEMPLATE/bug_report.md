---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
---

## What happened?

## Steps to reproduce

## Expected behavior

## Environment
- Python version:
- Operating system:
